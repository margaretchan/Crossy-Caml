# Crossy-Caml
Variation of "Crossy Road" game made in OCaml
