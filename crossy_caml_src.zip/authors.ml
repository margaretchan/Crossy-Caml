(* [hours_worked] is the list of hours worked by Margaret, David, and Kevin *)
let hours_worked = [10, 10, 10]