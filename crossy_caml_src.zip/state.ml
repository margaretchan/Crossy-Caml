type state = 
  | Start
  | Game
  | Lose
  | Win

