type state = 
  | Start
  | Game
  | Lose
  | Pause 
  | Continue
  | Select

type difficulty = 
  | Easy 
  | Normal 
  | Hard

