type dir = Down | Left | Right | No

type pos = int * int

type block_type = 
  | SmallB
  | LargeB
  | GoodB